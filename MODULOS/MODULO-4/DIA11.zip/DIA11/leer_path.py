

import os

log_file =  open(os.path.abspath("utils/logo.log")) #! FileNotFoundError <- Busca y sino encuentra ERROR

print(log_file)

# <_io.TextIOWrapper name='C:\\Users\\mauuu\\OneDrive\\Escritorio\\OTEC 2024\\MODULO-4\\
#   DIA11\\utils\\logo.log' mode='r' encoding='cp1252'>

