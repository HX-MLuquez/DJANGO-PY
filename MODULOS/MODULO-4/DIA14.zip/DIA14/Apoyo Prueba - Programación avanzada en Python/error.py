# class Error(Exception):
#     pass


class  SubTipoInvalidoException(Exception):
    pass 

class LargoExcedidoException(Exception):
    pass