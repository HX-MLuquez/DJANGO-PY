


with open("sasa.txt") as file:
    linea1 = file.readline()
    linea2 = file.readline()
    linea3 = file.readline()
    