class Error(Exception):
    pass

class DimensionError(Error):
    def __init__(self, mensaje, dimension, max) -> None:
        pass
    def __str__(self) -> str:
        return super().__str__()