


with open("momo.log", "w") as log:
    log.write(f"Holitis")