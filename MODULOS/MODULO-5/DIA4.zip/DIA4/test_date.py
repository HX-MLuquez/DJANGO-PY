from datetime import datetime

fecha_ya = datetime.now()

print(fecha_ya) # -> 2024-07-09 23:42:26.675052