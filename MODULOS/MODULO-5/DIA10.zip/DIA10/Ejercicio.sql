

CREATE DATABASE producto_feria;

\c producto_feria
\dt

SELECT