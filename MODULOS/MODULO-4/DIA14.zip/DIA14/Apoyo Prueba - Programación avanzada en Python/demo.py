

from campaña import Campaña 
from datetime import date 

from anuncio import Video, Display, Social 


mi_camp = "......( , , , , [<Video>])"

try:
    print("")
    
    # anuncios[0]
    
except Exception as e:
    print("")
finally:
    print(mi_camp)
