"""
a = 2 
a += 2 
a -= 2 
a *= 3 
a /= 3
"""
a = 6
print(f'1. {a}') # 6
a = 2 
print(f'2. {a}') # 2
a += 2 
print(f'3. {a}') # 4
a = a + 2
print(f'4. {a}') # 6
a -= 1 
print(f'5. {a}') # 5
a = a - 1
print(f'6. {a}') # 4
a *= 3 
print(f'7. {a}') # 12
a = a * 3
print(f'8. {a}') # 36
a /= 2
print(f'9. {a}') # 18
a = a / 2
print(f'10. {a}') # 9
