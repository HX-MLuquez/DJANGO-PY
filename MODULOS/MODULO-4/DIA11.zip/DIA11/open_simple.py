



with open('test.html', 'r') as file:
    doc_html = file.read()
    
    print(doc_html)