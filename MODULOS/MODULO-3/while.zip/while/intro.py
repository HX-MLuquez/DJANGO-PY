print("hola")
# CICLO / CORTE
swap = True # CASO BASE - CORTE
count = 1
while swap:
    print(f"-> {count}")
    if count == 10:
        print("En corte")
        swap = False # CASO CORTE
    count = count + 1
    
print("continua el code")


