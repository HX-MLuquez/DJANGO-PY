

class Reunion:
    def __init__(self, titulo: str, hora: str) -> None:
        self.titulo = titulo
        self.hora = hora
