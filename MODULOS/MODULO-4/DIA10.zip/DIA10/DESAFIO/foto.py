

class Foto:
    MAX = 2000
    def __init__(self) -> None:
        # __ancho
        # __alto
        pass